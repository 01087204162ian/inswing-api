const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const axios = require('axios');
const FormData = require('form-data');

const db = require('../db');
const { s3Client, Upload } = require('../config/s3');
const { generateSwingComment } = require('../services/commentService');
const { generateCoaching, getFocusTag, calculateChange, getCompareTag, callClaudeAPI } = require('../services/aiCoachingService');
const { buildSummaryPrompt, buildQuestionPrompt } = require('../services/coachPrompt');

const router = express.Router();

// WebSocket 브로드캐스트 헬퍼 함수
async function broadcastSwingAnalyzed(swingId, metrics, aiComment, focusTag) {
  const realtimeUrl = process.env.REALTIME_URL || 'http://localhost:4100';
  const sessionId = `sess_${swingId}`;

  try {
    // swing_analyzed 이벤트 브로드캐스트
    await axios.post(`${realtimeUrl}/api/broadcast`, {
      topic: `session:${sessionId}`,
      event: 'event:new',
      payload: {
        type: 'swing_analyzed',
        session_id: sessionId,
        swing_id: swingId,
        author_role: 'ai',
        author_id: 'ai_system',
        message: `스윙 분석이 완료되었습니다.`,
        meta: {
          swing_id: swingId,
          metrics: metrics,
          focus_tag: focusTag,
          ts: Date.now()
        }
      }
    });

    // ai_insight 이벤트 브로드캐스트 (AI 코멘트가 있는 경우)
    if (aiComment) {
      await axios.post(`${realtimeUrl}/api/broadcast`, {
        topic: `session:${sessionId}`,
        event: 'event:new',
        payload: {
          type: 'ai_insight',
          session_id: sessionId,
          swing_id: swingId,
          author_role: 'ai',
          author_id: 'ai_coach',
          message: aiComment,
          meta: {
            swing_id: swingId,
            persona: 'calm_mentor',
            ts: Date.now()
          }
        }
      });
    }
  } catch (err) {
    console.error('[Swings] WebSocket 방송 오류:', err.message);
    throw err;
  }
}

// 🔥 추가
const authMiddleware = require('../middlewares/auth');
router.use(authMiddleware);
// ===== File Upload 설정 =====
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) => {
    const uniqueName =
      Date.now() +
      '-' +
      Math.round(Math.random() * 1e9) +
      path.extname(file.originalname);
    cb(null, uniqueName);
  }
});
const upload = multer({ storage });

/**
 * 최근 N개 스윙의 평균 메트릭 계산
 * @param {number} userId - 사용자 ID
 * @param {number} limit - 가져올 스윙 개수 (기본 20)
 * @returns {Object|null} 평균 메트릭 또는 null
 */
async function getPreviousMetrics(userId, limit = 20) {
  try {
    const [rows] = await db.query(
      `
      SELECT
        AVG(m.tempo_ratio) as avg_tempo_ratio,
        AVG(m.head_movement_pct) as avg_head_movement_pct,
        AVG(m.balance_score) as avg_balance_score,
        AVG(m.backswing_angle) as avg_backswing_angle,
        AVG(m.follow_through_angle) as avg_follow_through_angle
      FROM swings s
      INNER JOIN metrics m ON s.id = m.swing_id
      WHERE s.user_id = ?
      ORDER BY s.created_at DESC
      LIMIT ?
      `,
      [userId, limit]
    );

    if (!rows || rows.length === 0 || !rows[0].avg_tempo_ratio) {
      return null;
    }

    const row = rows[0];
    return {
      tempo_ratio: row.avg_tempo_ratio ? parseFloat(row.avg_tempo_ratio) : null,
      head_movement_pct: row.avg_head_movement_pct ? parseFloat(row.avg_head_movement_pct) : null,
      balance_score: row.avg_balance_score ? parseFloat(row.avg_balance_score) : null,
      backswing_angle: row.avg_backswing_angle ? parseFloat(row.avg_backswing_angle) : null,
      follow_through_angle: row.avg_follow_through_angle ? parseFloat(row.avg_follow_through_angle) : null
    };
  } catch (err) {
    console.error('평균 메트릭 계산 실패:', err);
    return null;
  }
}

// 1) 스윙 업로드 + AI 분석 + S3 저장
router.post('/', upload.single('video'), async (req, res, next) => {
  try {
    const userId = req.user.id;
    const { club_type, shot_side } = req.body;

    if (!req.file) {
      return res.status(400).json({ ok: false, error: 'No video uploaded' });
    }

    const connection = await db.getConnection();
    await connection.beginTransaction();

    try {
      // ==== AI 분석 ====
      let metrics;
      try {
        const formData = new FormData();
        formData.append('video', fs.createReadStream(req.file.path));

        const aiResponse = await axios.post(
          'http://localhost:5000/analyze',
          formData,
          { headers: formData.getHeaders(), timeout: 900000 }
        );

        // Python 서버에서 에러를 반환한 경우 처리
        // 문서 요구사항: 응답 형식이 metrics로 변경됨
        const aiData = aiResponse.data || {};
        if (aiData.error || (!aiData.metrics && !aiData.analysis)) {
          const rawError = aiData.error;

          // invalid_swing 플래그가 있는 경우도 처리
          if (aiData.invalid_swing === true) {
            const error = new Error('스윙 자세를 감지할 수 없습니다.');
            error.status = 400;
            error.clientMessage = '스윙 동작을 감지하지 못했습니다. 스윙 전체가 화면에 나오도록 다시 촬영해 주세요.';
            throw error;
          }

          // 스윙을 감지하지 못한 경우: 사용자에게 안내하고 400으로 종료
          const isNoSwing =
            typeof rawError === 'string' &&
            rawError.includes('스윙 자세를 감지할 수 없습니다');

          if (isNoSwing) {
            const error = new Error('스윙 자세를 감지할 수 없습니다.');
            error.status = 400;
            error.clientMessage =
              '스윙 동작을 감지하지 못했습니다. 스윙 전체가 화면에 나오도록 다시 촬영해 주세요.';
            throw error;
          }

          // 그 외 AI 서버 쪽 에러는 일반 에러로 처리 → 아래 catch에서 분기
          const error = new Error(rawError || 'AI 분석 중 오류가 발생했습니다.');
          throw error;
        }

        // 문서 요구사항: 응답 형식 변경 (analysis -> metrics)
        const analysis = aiData.metrics || aiData.analysis || {};
        metrics = {
          backswing_angle: analysis.backswing_angle,
          impact_speed: analysis.impact_speed,
          follow_through_angle: analysis.follow_through_angle,
          balance_score: analysis.balance_score,
          tempo_ratio: analysis.tempo_ratio ?? null,
          backswing_time_sec: analysis.backswing_time_sec ?? null,
          downswing_time_sec: analysis.downswing_time_sec ?? null,
          head_movement_pct: analysis.head_movement_pct ?? null,
          shoulder_rotation_range: analysis.shoulder_rotation_range ?? null,
          hip_rotation_range: analysis.hip_rotation_range ?? null,
          rotation_efficiency: analysis.rotation_efficiency ?? null,
          overall_score: analysis.overall_score ?? null
        };
      } catch (err) {
        // Axios 에러 형태에서 Python AI 서버의 응답을 파싱
        const axiosRes = err.response;
        const status = axiosRes?.status || err.status;
        const rawError =
          axiosRes?.data?.error ||
          err.clientMessage ||
          err.message;

        const isNoSwing =
          typeof rawError === 'string' &&
          (rawError.includes('스윙 자세를 감지할 수 없습니다') ||
            rawError.includes('스윙하는 사람의 전체 몸이 화면에 충분히 보이지 않습니다'));

        // 스윙 자체를 감지하지 못한 경우 → 더미 데이터 사용 금지, 그대로 400 반환
        if (status === 400 && isNoSwing) {
          await connection.rollback();
          if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
          return res.status(400).json({
            ok: false,
            error:
              '스윙 동작을 감지하지 못했습니다. 스윙 전체가 화면에 나오도록, 사람의 몸이 잘 보이게 다시 촬영해 주세요.'
          });
        }

        // 그 외: 서버 장애, 타임아웃 등 → 더미 메트릭으로 Fallback
        console.error('AI 서버 오류, 더미 데이터 사용:', err);
        metrics = {
          backswing_angle: (Math.random() * 30 + 70).toFixed(2),
          impact_speed: (Math.random() * 20 + 90).toFixed(2),
          follow_through_angle: (Math.random() * 40 + 110).toFixed(2),
          balance_score: (Math.random() * 0.3 + 0.7).toFixed(2),
          tempo_ratio: null,
          backswing_time_sec: null,
          downswing_time_sec: null,
          head_movement_pct: null,
          shoulder_rotation_range: null,
          hip_rotation_range: null,
          rotation_efficiency: null,
          overall_score: null
        };
      }

      // ==== S3 업로드 ====
      const fileStream = fs.createReadStream(req.file.path);
      const s3Key = `videos/${Date.now()}-${req.file.originalname}`;

      const uploadParams = {
        Bucket: process.env.AWS_S3_BUCKET,
        Key: s3Key,
        Body: fileStream,
        ContentType: req.file.mimetype
      };

      const s3Upload = new Upload({ client: s3Client, params: uploadParams });
      await s3Upload.done();
      const videoUrl = `https://${process.env.CLOUDFRONT_DOMAIN}/${s3Key}`;

      fs.unlinkSync(req.file.path); // 로컬 파일 삭제

      // ==== 사용자 이름 조회 ====
      const [userRows] = await connection.query(
        'SELECT name FROM users WHERE id = ?',
        [userId]
      );
      const userName = userRows.length > 0 ? userRows[0].name : null;

      // ==== 스윙 저장 + 코멘트 생성 ====
      let aiComment;
      let previousCompareTag = null;
      const useAICoaching = process.env.USE_AI_COACHING === 'true';
      const comparePrevious = req.query.compare === 'true';

      // 평소 대비 비교가 요청된 경우 평균 메트릭 계산
      let previousMetrics = null;
      if (comparePrevious && useAICoaching) {
        previousMetrics = await getPreviousMetrics(userId, 20);
      }

      if (useAICoaching) {
        try {
          aiComment = await generateCoaching(
            metrics,
            {
              user_id: userId,
              user_name: userName,
              club_type,
              shot_side
            },
            null,
            previousMetrics
          );

          // 비교 태그 생성
          if (previousMetrics) {
            const changes = calculateChange(metrics, previousMetrics);
            previousCompareTag = getCompareTag(changes);
          }
        } catch (err) {
          console.error('AI 코칭 생성 실패, 규칙 기반 코멘트로 대체:', err);
          aiComment = generateSwingComment(metrics, {
            feelingCode: null,
            clubType: club_type,
            shotSide: shot_side
          });
        }
      } else {
        aiComment = generateSwingComment(metrics, {
          feelingCode: null,
          clubType: club_type,
          shotSide: shot_side
        });
      }

      const [swingResult] = await connection.query(
        'INSERT INTO swings (user_id, video_url, club_type, shot_side, comment) VALUES (?, ?, ?, ?, ?)',
        [userId, videoUrl, club_type, shot_side, aiComment]
      );
      const swingId = swingResult.insertId;

      // metrics 저장
      await connection.query(
        `
        INSERT INTO metrics (
          swing_id,
          backswing_angle,
          impact_speed,
          follow_through_angle,
          balance_score,
          tempo_ratio,
          backswing_time_sec,
          downswing_time_sec,
          head_movement_pct,
          shoulder_rotation_range,
          hip_rotation_range,
          rotation_efficiency,
          overall_score
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `,
        [
          swingId,
          metrics.backswing_angle,
          metrics.impact_speed,
          metrics.follow_through_angle,
          metrics.balance_score,
          metrics.tempo_ratio,
          metrics.backswing_time_sec,
          metrics.downswing_time_sec,
          metrics.head_movement_pct,
          metrics.shoulder_rotation_range,
          metrics.hip_rotation_range,
          metrics.rotation_efficiency,
          metrics.overall_score
        ]
      );

      await connection.commit();

      // 핵심 포인트 태그 생성
      const focusTag = getFocusTag(metrics);

      const response = {
        ok: true,
        swing: {
          id: swingId,
          video_url: videoUrl,
          club_type,
          shot_side,
          comment: aiComment,
          focus_tag: focusTag
        },
        metrics
      };

      // 비교 태그가 있으면 추가
      if (previousCompareTag) {
        response.swing.previous_compare_tag = previousCompareTag;
      }

      // session_id 추가 (문서 요구사항)
      response.swing_id = swingId;
      response.session_id = `sess_${swingId}`;

      // 문서 요구사항: WebSocket 방송 (swing_analyzed + ai_insight)
      try {
        await broadcastSwingAnalyzed(swingId, metrics, aiComment, focusTag);
      } catch (broadcastErr) {
        console.error('[Swings] WebSocket 방송 실패 (무시):', broadcastErr.message);
        // 방송 실패해도 응답은 정상 반환
      }

      return res.json(response);
    } catch (err) {
      await connection.rollback();
      if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
      throw err;
    } finally {
      connection.release();
    }
  } catch (err) {
    err.clientMessage = '영상 업로드 중 오류가 발생했습니다.';
    return next(err);
  }
});


// 2) 스윙 단건 조회
// 2) 스윙 단건 조회
router.get('/:id', async (req, res, next) => {
  try {
    const swingId = req.params.id;
    const userId = req.user.id;

    const [rows] = await db.query(
      `
      SELECT
        s.id,
        s.video_url,
        s.club_type,
        s.shot_side,
        s.created_at,
        s.comment,
        m.backswing_angle,
        m.impact_speed,
        m.follow_through_angle,
        m.balance_score,
        m.tempo_ratio,
        m.backswing_time_sec,
        m.downswing_time_sec,
        m.head_movement_pct,
        m.shoulder_rotation_range,
        m.hip_rotation_range,
        m.rotation_efficiency,
        m.overall_score,
        f.feeling_code,
        f.note
      FROM swings s
      LEFT JOIN metrics m ON s.id = m.swing_id
      LEFT JOIN feelings f ON s.id = f.swing_id
      WHERE s.id = ? AND s.user_id = ?
      `,
      [swingId, userId]
    );
    const swings = rows.map(row => ({
      id: row.id,
      video_url: row.video_url,
      club_type: row.club_type,
      shot_side: row.shot_side,
      created_at: row.created_at,
      comment: row.comment,              // 👈 추가
      metrics: {
        backswing_angle: row.backswing_angle,
        impact_speed: row.impact_speed,
        follow_through_angle: row.follow_through_angle,
        balance_score: row.balance_score,
        tempo_ratio: row.tempo_ratio,
        backswing_time_sec: row.backswing_time_sec,
        downswing_time_sec: row.downswing_time_sec,
        head_movement_pct: row.head_movement_pct,
        shoulder_rotation_range: row.shoulder_rotation_range,
        hip_rotation_range: row.hip_rotation_range,
        rotation_efficiency: row.rotation_efficiency,
        overall_score: row.overall_score
      },
      feeling: row.feeling_code
        ? {
            feeling_code: row.feeling_code,
            note: row.note
          }
        : null
    }));
    if (rows.length === 0) {
      return res.status(404).json({ ok: false, error: 'Swing not found' });
    }

    const row = rows[0];

    const metrics = {
      backswing_angle: row.backswing_angle,
      impact_speed: row.impact_speed,
      follow_through_angle: row.follow_through_angle,
      balance_score: row.balance_score,
      tempo_ratio: row.tempo_ratio,
      backswing_time_sec: row.backswing_time_sec,
      downswing_time_sec: row.downswing_time_sec,
      head_movement_pct: row.head_movement_pct,
      shoulder_rotation_range: row.shoulder_rotation_range,
      hip_rotation_range: row.hip_rotation_range,
      rotation_efficiency: row.rotation_efficiency,
      overall_score: row.overall_score
    };

    const feeling = row.feeling_code
      ? {
          feeling_code: row.feeling_code,
          note: row.note
        }
      : null;

    // DB에 저장된 코멘트가 있으면 우선 사용,
    // 없으면 규칙 기반 코멘트 생성
    let comment = row.comment;
    if (!comment) {
      comment = generateSwingComment(metrics, {
        feelingCode: feeling?.feeling_code || null,
        clubType: row.club_type,
        shotSide: row.shot_side
      });
    }

    // 핵심 포인트 태그 생성
    const focusTag = getFocusTag(metrics);

    // 한 줄 요약 생성 (LLM, 120자 이내)
    let summary = null;
    try {
      const analysis = {
        swing: {
          club_type: row.club_type,
          shot_side: row.shot_side,
          created_at: row.created_at
        },
        metrics
      };
      const prompt = buildSummaryPrompt({ analysis, feeling });
      const text = await callClaudeAPI(prompt, { max_tokens: 160, temperature: 0.3 });
      if (text) {
        summary = text.trim();
        if (summary.length > 120) {
          summary = summary.slice(0, 120).trim();
        }
      }
    } catch (err) {
      console.warn('[Swings] summary 생성 실패 (무시):', err.message);
      summary = comment ? String(comment).slice(0, 120).trim() : null;
    }

    return res.json({
      ok: true,
      swing: {
        id: row.id,
        video_url: row.video_url,
        club_type: row.club_type,
        shot_side: row.shot_side,
        created_at: row.created_at
      },
      metrics,
      feeling,
      comment,
      summary,
      focus_tag: focusTag
    });
  } catch (err) {
    return next(err);
  }
});


// 3) 히스토리 리스트 조회
// 3) 히스토리 리스트 조회
router.get('/', async (req, res, next) => {
  try {
    const userId = req.user.id;

    // 사용자 이름 조회
    const [userRows] = await db.query(
      'SELECT name FROM users WHERE id = ?',
      [userId]
    );
    const userName = userRows.length > 0 && userRows[0].name ? userRows[0].name : null;

    const [rows] = await db.query(
      `
      SELECT
        s.id,
        s.video_url,
        s.club_type,
        s.shot_side,
        s.comment,
        s.created_at,

        m.backswing_angle,
        m.impact_speed,
        m.follow_through_angle,
        m.balance_score,
        m.tempo_ratio,
        m.backswing_time_sec,
        m.downswing_time_sec,
        m.head_movement_pct,
        m.shoulder_rotation_range,
        m.hip_rotation_range,
        m.rotation_efficiency,
        m.overall_score,

        f.feeling_code,
        f.note,

        -- 🔥 추가: 오늘 스윙 여부
        DATE(s.created_at) = CURDATE() AS is_today,

        -- 🔥 추가: 진행 중 루틴 세션에 포함되는지
        rs.id IS NOT NULL AS in_active_routine,
        rs.id             AS routine_session_id

      FROM swings s
      LEFT JOIN metrics  m ON s.id = m.swing_id
      LEFT JOIN feelings f ON s.id = f.swing_id

      -- 🔥 추가: 루틴 세션 조인(진행 중 세션 기준)
      LEFT JOIN routine_sessions rs
        ON rs.user_id = s.user_id
       AND rs.status = 'IN_PROGRESS'
       AND s.created_at >= rs.start_at
       AND (rs.end_at IS NULL OR s.created_at <= rs.end_at)

      WHERE s.user_id = ?
      ORDER BY s.created_at DESC
      `,
      [userId]
    );

    // 전체 평균 메트릭 계산 (비교용)
    const previousMetrics = await getPreviousMetrics(userId, 20);

    const swings = rows.map(row => {
      const metrics = {
        backswing_angle: row.backswing_angle,
        impact_speed: row.impact_speed,
        follow_through_angle: row.follow_through_angle,
        balance_score: row.balance_score,
        tempo_ratio: row.tempo_ratio,
        backswing_time_sec: row.backswing_time_sec,
        downswing_time_sec: row.downswing_time_sec,
        head_movement_pct: row.head_movement_pct,
        shoulder_rotation_range: row.shoulder_rotation_range,
        hip_rotation_range: row.hip_rotation_range,
        rotation_efficiency: row.rotation_efficiency,
        overall_score: row.overall_score
      };

      // 핵심 포인트 태그 생성
      const focusTag = getFocusTag(metrics);

      // 평소 대비 비교 태그 생성
      let previousCompareTag = null;
      if (previousMetrics) {
        const changes = calculateChange(metrics, previousMetrics);
        previousCompareTag = getCompareTag(changes);
      }

      return {
        id: row.id,
        video_url: row.video_url,
        club_type: row.club_type,
        shot_side: row.shot_side,
        created_at: row.created_at,
        comment: row.comment, // AI 코멘트
        focus_tag: focusTag,
        previous_compare_tag: previousCompareTag,

        // 🔹 루틴/오늘 정보
        is_today:          !!row.is_today,
        in_active_routine: !!row.in_active_routine,
        routine_session_id: row.routine_session_id,

        metrics,
        feeling: row.feeling_code
          ? {
              feeling_code: row.feeling_code,
              note: row.note
            }
          : null
      };
    });

    return res.json({ ok: true, swings, user_name: userName });
  } catch (err) {
    err.clientMessage = '스윙 히스토리를 불러오는 중 오류가 발생했습니다.';
    return next(err);
  }
});

// 🔥 질문 코칭 API
router.post('/:id/questions', async (req, res, next) => {
  try {
    const swingId = parseInt(req.params.id, 10);
    const userId = req.user.id;
    const { question } = req.body || {};

    // 1) 기본 검증
    if (!swingId || Number.isNaN(swingId)) {
      return res.status(400).json({ ok: false, error: '유효하지 않은 스윙 ID입니다.' });
    }

    if (!question || typeof question !== 'string' || !question.trim()) {
      return res.status(400).json({ ok: false, error: '질문 내용을 입력해 주세요.' });
    }

    const trimmedQuestion = question.trim();

    // 2) 스윙 + 메트릭 조회 (본인 것만)
    const [rows] = await db.query(
      `
      SELECT
        s.id,
        s.user_id,
        s.club_type,
        s.shot_side,
        s.created_at,
        m.backswing_angle,
        m.impact_speed,
        m.follow_through_angle,
        m.balance_score,
        m.tempo_ratio,
        m.backswing_time_sec,
        m.downswing_time_sec,
        m.head_movement_pct,
        m.shoulder_rotation_range,
        m.hip_rotation_range,
        m.rotation_efficiency,
        m.overall_score
      FROM swings s
      LEFT JOIN metrics m ON m.swing_id = s.id
      WHERE s.id = ? AND s.user_id = ?
      `,
      [swingId, userId]
    );

    if (!rows || rows.length === 0) {
      return res.status(404).json({ ok: false, error: '스윙을 찾을 수 없습니다.' });
    }

    const row = rows[0];

    // 3) analysis 객체 구성 (프롬프트용)
    const metrics = {
      backswing_angle: row.backswing_angle,
      impact_speed: row.impact_speed,
      follow_through_angle: row.follow_through_angle,
      balance_score: row.balance_score,
      tempo_ratio: row.tempo_ratio,
      backswing_time_sec: row.backswing_time_sec,
      downswing_time_sec: row.downswing_time_sec,
      head_movement_pct: row.head_movement_pct,
      shoulder_rotation_range: row.shoulder_rotation_range,
      hip_rotation_range: row.hip_rotation_range,
      rotation_efficiency: row.rotation_efficiency,
      overall_score: row.overall_score
    };

    const analysis = {
      swing: {
        club_type: row.club_type,
        shot_side: row.shot_side,
        created_at: row.created_at
      },
      metrics
    };

    // 4) 질문을 DB에 저장 (status='pending')
    const connection = await db.getConnection();
    await connection.beginTransaction();

    try {
      const [insertResult] = await connection.query(
        `INSERT INTO swing_questions (swing_id, user_id, target, question_text, status)
         VALUES (?, ?, 'ai', ?, 'pending')`,
        [swingId, userId, trimmedQuestion]
      );
      const questionId = insertResult.insertId;

      // 5) 하이클래스 코치 프롬프트 생성
      const prompt = buildQuestionPrompt({
        question: trimmedQuestion,
        analysis
      });

      // 6) Claude API 호출
      let answerText = null;
      let status = 'canceled';

      try {
        const aiResponse = await callClaudeAPI(prompt, {
          max_tokens: 1000,  // 답변이 길어질 수 있으므로 충분한 토큰 제공
          temperature: 0.4
        });

        answerText = (aiResponse || '').trim();
        
        if (answerText) {
          status = 'answered';
          
          // 7) swing_answers 테이블에 답변 저장
          await connection.query(
            `INSERT INTO swing_answers 
             (question_id, answer_source, cause_text, solution_text, feel_image, drill_text, encouragement)
             VALUES (?, 'ai', ?, ?, NULL, NULL, NULL)`,
            [questionId, answerText, answerText] // 현재는 동일한 텍스트를 cause와 solution에 저장
          );

          // 8) swing_questions 상태 업데이트
          await connection.query(
            `UPDATE swing_questions 
             SET status = ?
             WHERE id = ?`,
            [status, questionId]
          );
        }
      } catch (llmError) {
        console.error('[Swings] Claude API 호출 오류:', llmError);
        // 실패 시 status는 'canceled'로 유지 (업데이트하지 않음)
      }

      await connection.commit();
      connection.release();

      // 9) 응답 반환
      if (status === 'answered') {
        // 답변 객체 형태로 반환 (프론트엔드 호환성을 위해 text 필드 추가)
        return res.json({
          ok: true,
          question_id: questionId,
          swing_id: swingId,
          question: trimmedQuestion,
          answer: {
            text: answerText,  // 프론트엔드가 우선 사용
            source: 'ai',
            cause: answerText,  // DB 저장용 (swing_answers 테이블 구조 호환)
            solution: answerText,
            feel_image: null,
            drill: null,
            encouragement: null
          },
          status: 'answered'
        });
      } else {
        return res.status(500).json({
          ok: false,
          question_id: questionId,
          error: 'AI 코치 응답 생성 중 오류가 발생했습니다.'
        });
      }
    } catch (dbError) {
      await connection.rollback();
      connection.release();
      throw dbError;
    }
  } catch (err) {
    console.error('[Swings] 질문 코칭 생성 오류:', err);
    err.clientMessage = err.clientMessage || '코칭 답변 생성 중 오류가 발생했습니다.';
    return next(err);
  }
});

// 🔥 질문 히스토리 조회 API
router.get('/:id/questions', async (req, res, next) => {
  try {
    const swingId = parseInt(req.params.id, 10);
    const userId = req.user.id;

    // 1) 기본 검증
    if (!swingId || Number.isNaN(swingId)) {
      return res.status(400).json({ ok: false, error: '유효하지 않은 스윙 ID입니다.' });
    }

    // 2) 스윙 소유 확인
    const [swingRows] = await db.query(
      'SELECT id FROM swings WHERE id = ? AND user_id = ?',
      [swingId, userId]
    );

    if (!swingRows || swingRows.length === 0) {
      return res.status(404).json({ ok: false, error: '스윙을 찾을 수 없습니다.' });
    }

    // 3) 질문/답변 히스토리 조회 (swing_answers LEFT JOIN)
    const [rows] = await db.query(
      `SELECT 
         q.id,
         q.question_text,
         q.status,
         q.target,
         q.created_at,
         a.id AS answer_id,
         a.answer_source,
         a.cause_text,
         a.solution_text,
         a.feel_image,
         a.drill_text,
         a.encouragement,
         a.created_at AS answer_created_at
       FROM swing_questions q
       LEFT JOIN swing_answers a ON a.question_id = q.id
       WHERE q.user_id = ? AND q.swing_id = ?
       ORDER BY q.created_at DESC
       LIMIT 50`,
      [userId, swingId]
    );

    return res.json({
      ok: true,
      swing_id: swingId,
      questions: rows.map(row => ({
        id: row.id,
        question: row.question_text,
        status: row.status,
        target: row.target,
        created_at: row.created_at,
        answer: row.answer_id ? {
          id: row.answer_id,
          source: row.answer_source,
          cause: row.cause_text,
          solution: row.solution_text,
          feel_image: row.feel_image,
          drill: row.drill_text,
          encouragement: row.encouragement,
          created_at: row.answer_created_at
        } : null
      }))
    });
  } catch (err) {
    console.error('[Swings] 질문 히스토리 조회 오류:', err);
    err.clientMessage = err.clientMessage || '질문 히스토리를 불러오는 중 오류가 발생했습니다.';
    return next(err);
  }
});

// 코칭 재생성 API
router.post('/:id/regenerate-coaching', async (req, res, next) => {
  try {
    const swingId = parseInt(req.params.id);
    const userId = req.user.id;

    if (!swingId || isNaN(swingId)) {
      return res.status(400).json({ ok: false, error: '유효하지 않은 스윙 ID입니다.' });
    }

    const connection = await db.getConnection();
    try {
      // 스윙 정보 조회 (사용자 확인 포함)
      const [swings] = await connection.query(
        `SELECT s.id, s.user_id, s.club_type, s.shot_side, s.comment,
                m.backswing_angle, m.impact_speed, m.follow_through_angle, m.balance_score,
                m.tempo_ratio, m.backswing_time_sec, m.downswing_time_sec,
                m.head_movement_pct, m.shoulder_rotation_range, m.hip_rotation_range,
                m.rotation_efficiency, m.overall_score,
                f.feeling_code, f.note,
                u.name as user_name
         FROM swings s
         LEFT JOIN metrics m ON s.id = m.swing_id
         LEFT JOIN feelings f ON s.id = f.swing_id
         LEFT JOIN users u ON s.user_id = u.id
         WHERE s.id = ? AND s.user_id = ?`,
        [swingId, userId]
      );

      if (swings.length === 0) {
        return res.status(404).json({ ok: false, error: '스윙을 찾을 수 없습니다.' });
      }

      const swing = swings[0];

      if (!swing.club_type || !swing.shot_side) {
        return res.status(400).json({ ok: false, error: '스윙 정보가 불완전합니다.' });
      }

      // 메트릭 데이터 구성
      const metrics = {
        backswing_angle: swing.backswing_angle,
        impact_speed: swing.impact_speed,
        follow_through_angle: swing.follow_through_angle,
        balance_score: swing.balance_score,
        tempo_ratio: swing.tempo_ratio,
        backswing_time_sec: swing.backswing_time_sec,
        downswing_time_sec: swing.downswing_time_sec,
        head_movement_pct: swing.head_movement_pct,
        shoulder_rotation_range: swing.shoulder_rotation_range,
        hip_rotation_range: swing.hip_rotation_range,
        rotation_efficiency: swing.rotation_efficiency,
        overall_score: swing.overall_score
      };

      // 느낌 데이터 구성
      const feeling = swing.feeling_code
        ? {
            feeling_code: swing.feeling_code,
            note: swing.note
          }
        : null;

      // AI 코칭 재생성
      const useAICoaching = process.env.USE_AI_COACHING === 'true';
      const comparePrevious = req.query.compare === 'true';
      let newCoaching;
      let previousCompareTag = null;

      // 평소 대비 비교가 요청된 경우 평균 메트릭 계산
      let previousMetrics = null;
      if (comparePrevious && useAICoaching) {
        previousMetrics = await getPreviousMetrics(userId, 20);
      }

      if (useAICoaching) {
        try {
          newCoaching = await generateCoaching(
            metrics,
            {
              user_id: userId,
              user_name: swing.user_name,
              id: swingId,
              club_type: swing.club_type,
              shot_side: swing.shot_side
            },
            feeling,
            previousMetrics
          );

          // 비교 태그 생성
          if (previousMetrics) {
            const changes = calculateChange(metrics, previousMetrics);
            previousCompareTag = getCompareTag(changes);
          }
        } catch (err) {
          console.error('AI 코칭 재생성 실패, 규칙 기반 코멘트로 대체:', err);
          newCoaching = generateSwingComment(metrics, {
            feelingCode: feeling?.feeling_code || null,
            clubType: swing.club_type,
            shotSide: swing.shot_side
          });
        }
      } else {
        newCoaching = generateSwingComment(metrics, {
          feelingCode: feeling?.feeling_code || null,
          clubType: swing.club_type,
          shotSide: swing.shot_side
        });
      }

      // DB 업데이트
      await connection.query(
        'UPDATE swings SET comment = ? WHERE id = ? AND user_id = ?',
        [newCoaching, swingId, userId]
      );

      // 핵심 포인트 태그 생성
      const focusTag = getFocusTag(metrics);

      await connection.commit();

      const response = {
        ok: true,
        coaching: newCoaching,
        focus_tag: focusTag
      };

      // 비교 태그가 있으면 추가
      if (previousCompareTag) {
        response.previous_compare_tag = previousCompareTag;
      }

      return res.json(response);
    } catch (err) {
      await connection.rollback();
      throw err;
    } finally {
      connection.release();
    }
  } catch (err) {
    console.error('코칭 재생성 오류:', err);
    err.clientMessage = '코칭 재생성 중 오류가 발생했습니다.';
    return next(err);
  }
});

module.exports = router;
